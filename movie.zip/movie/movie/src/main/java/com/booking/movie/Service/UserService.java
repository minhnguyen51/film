package com.booking.movie.Service;

import com.booking.movie.Model.Dto.UserDTO;
import com.booking.movie.Repository.Entity.UserEnity;
import com.booking.movie.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;


    public ResponseEntity<?> register(UserDTO registerDTO) {
        if (userRepository.existsByUsername(registerDTO.getUsername())) {
            return ResponseEntity.badRequest().body("Username already exists");
        }
        if (userRepository.existsByEmail(registerDTO.getEmail())) {
            return ResponseEntity.badRequest().body("Email already exists");
        }
        UserEnity user = new UserEnity();
        user.setUsername(registerDTO.getUsername());
        user.setEmail(registerDTO.getEmail());
        user.setRole(registerDTO.getRole() != null ? registerDTO.getRole() : "USER");
        user.setPassword(registerDTO.getPassword());
        userRepository.save(user);
        return ResponseEntity.ok(user);
    }

    public ResponseEntity<?> login(UserDTO loginDTO) {
        Optional<UserEnity> userOpt = userRepository.findByUsername(loginDTO.getUsername());
        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Invalid username or password");
        }
        UserEnity user = userOpt.get();
        if (!user.getPassword().equals(loginDTO.getPassword())) {
            return ResponseEntity.badRequest().body("Invalid username or password");
        }
        UserDTO response = new UserDTO();
        response.setId(user.getId());
        response.setUsername(user.getUsername());
        response.setEmail(user.getEmail());
        response.setRole(user.getRole());
        // Không trả về password
        return ResponseEntity.ok(response);
    }
}