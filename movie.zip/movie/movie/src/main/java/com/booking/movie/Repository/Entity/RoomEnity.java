package com.booking.movie.Repository.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name= "rooms")
@Data
public class RoomEnity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "cinema_id")
    private int cinemaId;
    @Column(name = "name")
    private String name;


}
