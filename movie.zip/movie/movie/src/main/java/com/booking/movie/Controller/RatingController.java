package com.booking.movie.Controller;

import com.booking.movie.Service.RatingService;
import com.booking.movie.Model.Http.Request.RatingRequestDTO;
import com.booking.movie.Model.Dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@CrossOrigin("*")
@RestController
@RequestMapping("/api/rating")
public class RatingController {
    @Autowired
    private RatingService ratingService;

    // Đánh giá phim (POST)
    @PostMapping("/rate")
    public ResponseEntity<?> rateMovie(@RequestBody RatingRequestDTO request) {
        UserDTO user = request.getUser(); // Có thể null nếu là khách
        return ResponseEntity.ok(ratingService.rateMovie(request.getMovieId(), request.getRating(), user));
    }

    // Lấy điểm trung bình (GET)
    @GetMapping("/average")
    public ResponseEntity<?> getAverageRating(@RequestParam int movieId) {
        return ResponseEntity.ok(ratingService.getAverageRating(movieId));
    }
} 