package com.booking.movie.Repository.Entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name= "schedule")
@Data
public class ScheduleEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "movie_id")
    private int movieId;
    @Column(name = "room_id")
    private int roomId;
    @Column(name = "cinema_id")
    private  int cinemaId;
    @Column(name = "start_time")
    private LocalDateTime startTime;
    @Column(name = "end_time")
    private LocalDateTime endTime;
    @Column(name = "price")
    private double price;
}