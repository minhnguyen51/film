package com.booking.movie.Service;

import com.booking.movie.Model.Dto.BookingDTO;
import com.booking.movie.Repository.Entity.BookingEnity;
import com.booking.movie.Repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Base64;

import java.time.LocalDateTime;
import java.util.*;
import java.util.Optional;
import com.booking.movie.Repository.Entity.UserEnity;
import com.booking.movie.Repository.Entity.PaymentEnity;
import com.booking.movie.Repository.UserRepository;
import com.booking.movie.Repository.PaymentRepository;
import com.booking.movie.Model.Dto.UserDTO;

@Service
public class BookingService {
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PaymentRepository paymentRepository;

    // ĐẶT VÉ: Xử lý đầy đủ gồm kiểm tra ghế, tạo user nếu là khách, lưu booking, lưu payment, sinh QR
    public Map<String, Object> bookTicketAndReturnQR(BookingDTO req, boolean isLoggedIn, UserDTO user) throws Exception {
        // 1. Kiểm tra ghế đã được đặt chưa (theo seat_number và booking_time)
        Optional<BookingEnity> existingBooking = bookingRepository.findBySeatNumberAndBookingTime(
                req.getSeat_number(), req.getBooking_time()
        );
        Map<String, Object> result = new HashMap<>();
        if (existingBooking.isPresent()) {
            // 1.1 Nếu ghế đã được đặt, trả về thông báo lỗi
            result.put("success", false);
            result.put("message", "Ghế đã được đặt!");
            return result;
        }
        // 2. Xử lý user (nếu chưa đăng nhập thì tạo user ngẫu nhiên)
        Integer userId;
        if (isLoggedIn && user != null) {
            userId = user.getId();
        } else {
            UserEnity randomUser = new UserEnity();
            randomUser.setUsername(randomName());
            randomUser.setPassword(randomPassword());
            randomUser.setRole("KhachHang");
            randomUser.setEmail(randomEmail());
            userRepository.save(randomUser); // 2.1 Lưu user ngẫu nhiên
            userId = randomUser.getId();
        }
        // 3. Lưu thông tin booking vào database
        BookingEnity entity = new BookingEnity();
        entity.setSeatNumber(req.getSeat_number());
        entity.setMovieId(req.getMovie_id());
        entity.setUserId(userId);
        entity.setRoomId(req.getRoom_id());
        entity.setBookingTime(LocalDateTime.now());
        // --- Bổ sung logic voucher ---
        Double voucherDiscount = req.getVoucherDiscount() != null ? req.getVoucherDiscount() : 0.0;
        Double amount = req.getAmount() != null ? req.getAmount() : 0.0;
        Double finalAmount = amount * (1 - voucherDiscount);
        entity.setVoucherDiscount(voucherDiscount);
        entity.setFinalAmount(finalAmount);
        // --- End bổ sung ---
        bookingRepository.save(entity); // 3.1 Lưu booking
        // 4. Lưu thông tin thanh toán vào database
        PaymentEnity payment = new PaymentEnity();
        payment.setBookingId(entity.getId());
        payment.setAmount(req.getAmount());
        payment.setPaymentMethod(req.getPayment_method());
        payment.setPaymentTime(LocalDateTime.now());
        paymentRepository.save(payment); // 4.1 Lưu payment
        // 5. Sinh mã QR code cho booking
        String qrText = "BookingID: " + entity.getId() + ", Seat: " + entity.getSeatNumber() + ", Amount: " + req.getAmount();
        String qrBase64 = generateQRCodeBase64(qrText);
        // 6. Trả về kết quả booking thành công kèm mã QR
        result.put("success", true);
        result.put("bookingId", entity.getId());
        result.put("seat", entity.getSeatNumber());
        result.put("qrCodeBase64", qrBase64);
        return result;
    }

    /**
     * Xử lý toàn bộ logic booking từ request Map (FE gửi lên)
     */
    public Map<String, Object> handleBookingRequest(Map<String, Object> request) throws Exception {
        // 1. Parse dữ liệu booking
        BookingDTO bookingDTO = new BookingDTO();
        bookingDTO.setSeat_number((String) request.get("seat_number"));
        bookingDTO.setMovie_id(request.get("movie_id") != null ? ((Number)request.get("movie_id")).intValue() : null);
        bookingDTO.setAmount(request.get("amount") != null ? ((Number)request.get("amount")).doubleValue() : 0);
        bookingDTO.setPayment_method((String) request.get("payment_method"));
        // 2. Xác định user
        boolean isLoggedIn = request.get("isLoggedIn") != null && (Boolean) request.get("isLoggedIn");
        com.booking.movie.Model.Dto.UserDTO user = null;
        if (isLoggedIn && request.get("user") != null) {
            Map<String, Object> userMap = (Map<String, Object>) request.get("user");
            user = new com.booking.movie.Model.Dto.UserDTO();
            user.setId(userMap.get("id") != null ? ((Number)userMap.get("id")).intValue() : 0);
            user.setUsername((String) userMap.get("username"));
            user.setEmail((String) userMap.get("email"));
            // ... set các trường khác nếu cần
        }
        // 3. Không thao tác với customer_name hoặc trường không có trong DB
        // 4. Gọi logic booking đầy đủ
        return bookTicketAndReturnQR(bookingDTO, isLoggedIn, user);
    }

    private String randomName() {
        String[] names = {"Nguyen Van A", "Tran Thi B", "Le Van C", "Pham Thi D"};
        return names[new java.util.Random().nextInt(names.length)];
    }
    private String randomPassword() {
        return UUID.randomUUID().toString().substring(0, 8);
    }
    private String randomEmail() {
        return "user" + System.currentTimeMillis() + "@example.com";
    }

    /**
     * Sinh mã QR code từ chuỗi text đầu vào, trả về chuỗi base64 của ảnh QR.
     * Sử dụng thư viện ZXing để tạo QR code.
     *
     * @param text Nội dung muốn mã hoá vào QR code (ví dụ: thông tin booking)
     * @return Chuỗi base64 của ảnh QR code (để nhúng vào frontend)
     * @throws Exception Nếu có lỗi khi sinh QR
     */
    public String generateQRCodeBase64(String text) throws Exception {
        // 1. Khởi tạo QRCodeWriter từ thư viện ZXing
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        // 2. Tạo ma trận bit (BitMatrix) đại diện cho QR code với nội dung text, kích thước 200x200
        BitMatrix bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, 200, 200);
        // 3. Chuyển BitMatrix thành ảnh BufferedImage (ảnh QR code)
        BufferedImage qrImage = MatrixToImageWriter.toBufferedImage(bitMatrix);
        // 4. Ghi ảnh QR vào ByteArrayOutputStream dưới dạng PNG
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(qrImage, "png", baos);
        // 5. Mã hoá mảng byte ảnh thành chuỗi base64 để trả về cho frontend
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }

    // Thanh toán (giả lập)
    public Map<String, Object> processPayment(int bookingId, boolean isSuccess) {
        Map<String, Object> result = new HashMap<>();
        result.put("success", isSuccess);
        result.put("bookingId", bookingId);
        result.put("message", isSuccess ? "Thanh toán thành công" : "Thanh toán thất bại");
        return result;
    }

    // Lấy danh sách phim được đánh giá cao nhất (top 10 phim có rating trung bình cao nhất)
    public List<Map<String, Object>> getTopRatedMovies() {
        // Lấy tất cả các booking có rating > 0
        List<BookingEnity> allBookings = bookingRepository.findAll();
        Map<Integer, List<Integer>> movieRatings = new HashMap<>();
        for (BookingEnity b : allBookings) {
            if (b.getRating() > 0) {
                movieRatings.computeIfAbsent(b.getMovieId(), k -> new ArrayList<>()).add(b.getRating());
            }
        }
        // Tính trung bình rating cho từng phim
        List<Map<String, Object>> result = new ArrayList<>();
        for (Map.Entry<Integer, List<Integer>> entry : movieRatings.entrySet()) {
            int movieId = entry.getKey();
            List<Integer> ratings = entry.getValue();
            double avg = ratings.stream().mapToInt(i -> i).average().orElse(0);
            Map<String, Object> movieInfo = new HashMap<>();
            movieInfo.put("movieId", movieId);
            movieInfo.put("avgRating", avg);
            movieInfo.put("ratingCount", ratings.size());
            result.add(movieInfo);
        }
        // Sắp xếp giảm dần theo avgRating và lấy top 10
        result.sort((a, b) -> Double.compare((double) b.get("avgRating"), (double) a.get("avgRating")));
        return result.size() > 10 ? result.subList(0, 10) : result;
    }

    // Lấy danh sách số ghế đã đặt cho filmId
    public List<Integer> getBookedSeatsByFilmId(int filmId) {
        List<BookingEnity> bookings = bookingRepository.findByMovieId(filmId);
        List<Integer> seats = new ArrayList<>();
        for (BookingEnity b : bookings) {
            try {
                if (b.getSeatNumber() != null && !b.getSeatNumber().isEmpty()) {
                    seats.add(Integer.parseInt(b.getSeatNumber()));
                }
            } catch (NumberFormatException e) {
                // Bỏ qua nếu seatNumber không phải số
            }
        }
        return seats;
    }

    public List<String> getBookedSeatsByScheduleId(int scheduleId) {
        List<BookingEnity> bookings = bookingRepository.findByScheduleId(scheduleId);
        List<String> seats = new ArrayList<>();
        for (BookingEnity b : bookings) {
            if (b.getSeatNumber() != null && !b.getSeatNumber().isEmpty()) {
                seats.add(b.getSeatNumber());
            }
        }
        return seats;
    }
}
