package com.booking.movie.Model.Http.Response;

import lombok.Data;

@Data
public class ResMovieGetAllListMovie {
    String id;
}
