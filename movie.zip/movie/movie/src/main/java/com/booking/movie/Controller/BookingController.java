package com.booking.movie.Controller;

import com.booking.movie.Model.Dto.BookingDTO;

import com.booking.movie.Service.BookingService;
import com.booking.movie.Service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
@CrossOrigin("*")
@RestController
@RequestMapping("/api/booking")
public class BookingController {
    @Autowired
    private BookingService bookingService;

    @Autowired
    private MovieService movieService;

    // Đặt vé (check ghế, random user, lưu DB)
    @PostMapping("/book")
    public ResponseEntity<?> bookTicket(@RequestBody Map<String, Object> request) throws Exception {
        // Controller chỉ chuyển request sang service, không xử lý logic
        return ResponseEntity.ok(bookingService.handleBookingRequest(request));
    }

    // Thanh toán (giả lập)
    @PostMapping("/payment")
    public ResponseEntity<Map<String, Object>> processPayment(@RequestParam int bookingId, @RequestParam boolean isSuccess) {
        Map<String, Object> result = bookingService.processPayment(bookingId, isSuccess);
        return ResponseEntity.ok(result);
    }

    // Lấy danh sách phim được đánh giá cao nhất
    @GetMapping("/top-rated")
    public ResponseEntity<List<Map<String, Object>>> getTopRatedMovies() {
        List<Map<String, Object>> result = bookingService.getTopRatedMovies();
        return ResponseEntity.ok(result);
    }

    @GetMapping("/film/{filmId}/seats")
    public Map<String, Object> getFilmSeats(@PathVariable int filmId) {
        String filmName = movieService.findMovieById(filmId).getTitle();
        List<Integer> bookedSeats = bookingService.getBookedSeatsByFilmId(filmId);
        Map<String, Object> result = new HashMap<>();
        result.put("filmId", filmId);
        result.put("filmName", filmName);
        result.put("bookedSeats", bookedSeats);
        return result;
    }

    @GetMapping("/schedule/{scheduleId}/seats")
    public Map<String, Object> getScheduleSeats(@PathVariable int scheduleId) {
        List<String> bookedSeats = bookingService.getBookedSeatsByScheduleId(scheduleId);
        Map<String, Object> result = new HashMap<>();
        result.put("scheduleId", scheduleId);
        result.put("bookedSeats", bookedSeats);
        return result;
    }
}

