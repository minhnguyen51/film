package com.booking.movie.Repository.Entity;

import jakarta.persistence.*;
import lombok.Data;
@Entity
@Table(name= "users")
@Data
public class UserEnity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String username;
    private String password;
    private String role;
    private String email;
}
