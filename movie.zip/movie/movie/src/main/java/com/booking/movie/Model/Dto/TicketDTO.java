package com.booking.movie.Model.Dto;

import lombok.Data;

@Data
public class TicketDTO {
    private int id;
    private String ticket_type;
}
