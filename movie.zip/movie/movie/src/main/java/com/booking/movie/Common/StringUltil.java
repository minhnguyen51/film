package com.booking.movie.Common;

/**
 * StringUltil
 *
 * @author lequyphuc
 */
public class StringUltil {

    static boolean isNotEmpty(String str) {
        return str != null && !str.isEmpty();
    }
    private StringUltil() {
        
    }
}
