package com.booking.movie.Model.Dto;

import lombok.Data;

import java.time.LocalDate;
@Data
public class PaymentDTO {
    private int id;
    private String payment_method;
    private LocalDate payment_time;
}
