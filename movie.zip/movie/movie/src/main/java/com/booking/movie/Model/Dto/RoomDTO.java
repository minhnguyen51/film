package com.booking.movie.Model.Dto;

import lombok.Data;

@Data
public class RoomDTO {
    private int id;
    private String name;
    private int cinema_id;

}
