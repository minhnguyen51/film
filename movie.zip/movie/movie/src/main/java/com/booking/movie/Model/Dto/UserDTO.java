package com.booking.movie.Model.Dto;

import lombok.Data;

@Data
public class UserDTO {
    private int id;
    private String username;
    private String password;
    private String role;
    private String email;
}
