package com.booking.movie.Model.Http.Request;

import com.booking.movie.Model.Dto.UserDTO;
import lombok.Data;

@Data
public class RatingRequestDTO {
    private int movieId;
    private int rating;
    private UserDTO user; // Có thể null nếu là khách
}