package com.booking.movie.Model.Dto;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class BookingDTO {
    private int id;
    private String seat_number;
    private LocalDateTime booking_time;
    private int movie_id;
    private Double amount;
    private String payment_method;
    private int rating;
    private int room_id;
    private Double voucherDiscount;
    private Double finalAmount;
    private int schedule_id;
}
