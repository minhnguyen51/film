package com.booking.movie.Model.Http.Request;

public class ReqMovieGetAllListMovie {
    // có thể cái này chưa cần nhưng cái req khác cần
}
