package com.booking.movie.Service;

import com.booking.movie.Repository.BookingRepository;
import com.booking.movie.Repository.Entity.BookingEnity;
import com.booking.movie.Repository.Entity.UserEnity;
import com.booking.movie.Repository.UserRepository;
import com.booking.movie.Model.Dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class RatingService {
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private UserRepository userRepository;

    /**
     * Đánh giá phim: Nếu chưa đăng nhập thì random user, lưu vào users, sau đó tạo bản ghi mới trong bookings với movieId, userId, rating.
     * @param movieId id phim
     * @param rating số sao (1-5)
     * @param user user đã đăng nhập (nếu có), null nếu là khách
     * @return kết quả đánh giá
     */
    public Map<String, Object> rateMovie(int movieId, int rating, UserDTO user) {
        Integer userId;
        if (user != null && user.getId() != 0) {
            userId = user.getId();
        } else {
            UserEnity randomUser = new UserEnity();
            randomUser.setUsername(randomName());
            randomUser.setPassword(randomPassword());
            randomUser.setRole("KhachHang");
            randomUser.setEmail(randomEmail());
            userRepository.save(randomUser);
            userId = randomUser.getId();
        }
        BookingEnity ratingEntity = new BookingEnity();
        ratingEntity.setMovieId(movieId);
        ratingEntity.setUserId(userId);
        ratingEntity.setRating(rating);
        bookingRepository.save(ratingEntity);
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("message", "Đánh giá thành công: " + rating + " sao");
        return result;
    }

    /**
     * Lấy điểm trung bình rating của phim
     * @param movieId id phim
     * @return Map gồm average (double) và count (int)
     */
    public Map<String, Object> getAverageRating(int movieId) {
        List<BookingEnity> allRatings = bookingRepository.findAll();
        int total = 0, count = 0;
        for (BookingEnity b : allRatings) {
            if (b.getMovieId() != null && b.getRating() != null && b.getMovieId() == movieId && b.getRating() > 0) {
                total += b.getRating();
                count++;
            }
        }
        double avg = count == 0 ? 0 : (double) total / count;
        Map<String, Object> result = new HashMap<>();
        result.put("average", avg);
        result.put("count", count);
        return result;
    }

    // Hàm random user cho khách chưa đăng nhập
    private String randomName() {
        return "user" + System.currentTimeMillis();
    }
    private String randomPassword() {
        return "password" + System.currentTimeMillis();
    }
    private String randomEmail() {
        return "user" + System.currentTimeMillis() + "@example.com";
    }
} 