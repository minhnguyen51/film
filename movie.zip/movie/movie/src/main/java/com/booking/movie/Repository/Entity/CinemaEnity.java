package com.booking.movie.Repository.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name= "cinemas")
@Data
public class CinemaEnity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "name")
    private String name;
    @Column(name = "address")
    private String address;
    @Column(name = "phone")
    private String phone;

}
