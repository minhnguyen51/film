package com.booking.movie.Repository.Impl;

import com.booking.movie.Repository.MovieRepository;
import org.springframework.stereotype.Repository;

// demo thế này thôi có thể không cần impl mà chơi trực tiếp trong interface
public class MovieRepositoryImpl  {
}
