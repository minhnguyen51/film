package com.booking.movie.Repository.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
@Entity
@Table(name= "bookings")
@Data
public class BookingEnity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "user_id")
    private Integer userId;
    @Column(name = "movie_id")
    private Integer movieId;
    @Column(name = "room_id")
    private Integer roomId;
    @Column(name = "ticket_id")
    private Integer ticketId;
    @Column(name = "seat_number")
    private String seatNumber;
    @Column(name = "booking_time")
    private LocalDateTime bookingTime;
    @Column(name = "rating")
    private Integer rating;
    @Column(name = "voucher_discount")
    private Double voucherDiscount;
    @Column(name = "final_amount")
    private Double finalAmount;
    @Column(name = "schedule_id")
    private Integer scheduleId;
}
